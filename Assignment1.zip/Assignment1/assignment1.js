﻿/*\
    Michael Gailling
    822886651
    Assignment1 - BMR Calculator
\*/

function CalculateBMR() {
    var genderVal = Number(document.getElementById("genderInput").value);
    var ageVal = document.getElementById("ageInput").value;
    var heightVal = document.getElementById("heightInput").value;
    var weightVal = document.getElementById("weightInput").value;
    var activityVal = document.getElementById("activityInput").value;

    var bmr = (10 * weightVal) + (6.25 * heightVal) - (5 * ageVal) + genderVal;
    var tee = bmr * activityVal;

    alert(bmr +"\n" + tee);
}